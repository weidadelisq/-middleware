package com.quick.redis.util;

/**
 * @Author: wangxc
 * @GitHub: https://github.com/vector4wang
 * @CSDN: http://blog.csdn.net/qqhjqs?viewmode=contents
 * @BLOG: http://vector4wang.tk
 * @wxid: BMHJQS
 */
public class KeyUtil {
    public final static String COMPANY_KEY = "ResumeZero:company:";

    public final static String SCHOOL_KEY = "ResumeZero:school:";
}
