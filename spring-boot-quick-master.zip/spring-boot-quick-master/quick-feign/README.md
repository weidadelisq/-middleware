# 使用Feign作为http请求客户端

使用feign完成调用api的基本功能
http client 可以根据自己喜好更换httpclietn、okhttp...
添加hystrix


后续会了解Feign和hystrix高级功能
