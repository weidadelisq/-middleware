package com.dubbo.api;

public interface HelloService {
    String sayHello(String name);
}
