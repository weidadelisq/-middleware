package com.mq;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Created with IDEA
 * User: vector
 * Data: 2017/12/20
 * Time: 17:31
 * Description:http://javasampleapproach.com/spring-framework/spring-jms/activemq-create-springboot-activemq-response-management-application-sendto-annotation
 */
@SpringBootApplication
public class Application {
    public static void main(String[] args) {
        SpringApplication.run(Application.class);
    }
}
