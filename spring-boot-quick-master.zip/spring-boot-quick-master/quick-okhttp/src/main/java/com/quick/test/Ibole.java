package com.quick.test;

/**
 * Created with IDEA
 * User: vector
 * Data: 2017/9/30
 * Time: 15:36
 * Description:
 */
public class Ibole {
//    public static void main(String[] args) throws IOException {
//
//        ExecutorService executorService = Executors.newFixedThreadPool(10);
//
//        for(int i=0;i<10000;i++) {
//            executorService.execute(new Runnable() {
//                @Override
//                public void run() {
//                    try {
//                        testBug();
//                    } catch (IOException e) {
//                        e.printStackTrace();
//                    }
//                }
//            });
//        }
//
//
//    }
//
//    public static void testBug() throws IOException {
//        FormBody.Builder builder = new FormBody.Builder();
////        builder.add("candidateId", "a7800221-de6a-4455-83e4-62f4b10c3fa5");
//
//        builder.add("yearExpr", "0");
//        builder.add("location", "667");
//        builder.add("company", "123");
//        builder.add("gender", "1");
//        builder.add("realName", "123");
//        builder.add("mobile", RandomValue.getAddress().get("tel").toString());
//        builder.add("title", "123");
//        builder.add("degree", "2");
//        builder.add("email", RandomValue.getAddress().get("email").toString());
//
//        RequestBody body = builder.build();
//        Request request = new Request.Builder()
//                .url("http://api.ibole.net/candidate/create")
//                .header("User-Agent", "Dalvik/1.6.0 (Linux; U; Android 4.2.2; Droid4X-WIN Build/JDQ39E)")
//                .addHeader("authorization", "Basic ZGZkZjQ2Y2ZhMGNlYzJlOThhODgyY2QyZjJmODRkMWE6Yzg4NjlmZGE5ZTliNzdkMmY3OTEwNmQ0ODg2MTI1MzU=")
//                .post(body)
//                .build();
//
//        Response response = okHttpClient.newCall(request).execute();
//        System.out.println(response.body().string());
//    }
}
