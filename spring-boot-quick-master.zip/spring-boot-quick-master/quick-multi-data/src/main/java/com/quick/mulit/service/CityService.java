package com.quick.mulit.service;

import com.quick.mulit.entity.primary.City;

/**
 * Created with IDEA
 * User: vector
 * Data: 2017/8/22
 * Time: 19:13
 * Description:
 */
public interface CityService {
    City getCity(short i);
}
