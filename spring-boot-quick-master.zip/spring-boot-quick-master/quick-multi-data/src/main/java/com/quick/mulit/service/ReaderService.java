package com.quick.mulit.service;

import com.quick.mulit.entity.secondary.Reader;

/**
 * Created with IDEA
 * User: vector
 * Data: 2017/8/22
 * Time: 19:14
 * Description:
 */
public interface ReaderService {
    Reader getReader(int i);
}
