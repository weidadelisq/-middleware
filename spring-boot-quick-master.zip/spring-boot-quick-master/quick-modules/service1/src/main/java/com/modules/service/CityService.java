package com.modules.service;

import com.modules.entity.City;

/**
 * Created with IDEA
 * User: vector
 * Data: 2017/4/1
 * Time: 8:38
 */
public interface CityService {
    City selectById(int id);
}
