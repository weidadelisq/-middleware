package com.multi.test.service;

import com.modules.entity.City;

/**
 * @author vector
 * @Data 2018/8/10 0010
 * @Description TODO
 */
public interface CityService {
	City getCity(int id);
}
