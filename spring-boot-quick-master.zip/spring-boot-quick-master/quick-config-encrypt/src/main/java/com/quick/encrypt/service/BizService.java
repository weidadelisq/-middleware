package com.quick.encrypt.service;

import org.springframework.stereotype.Service;

/**
 * @author vector
 * @date: 2018/11/9 0009 16:33
 */
@Service
public class BizService {



}
