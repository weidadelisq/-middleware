package com.github.oauth.user;

import com.github.oauth.common.ICommonService;

public interface IUserService extends ICommonService<User> {
}