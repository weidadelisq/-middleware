package com.blueskykong.springboot.retry.serivce;

import java.util.Map;

/**
 * @author keets
 * @data 2018/5/8.
 */
public interface RetryService {

    String retry();
}
