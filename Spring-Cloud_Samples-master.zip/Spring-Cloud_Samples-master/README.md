## Spring-Cloud-Samples

#### based on Spring-Cloud `Finchley` version.

## modules

- spring-cloud-gateway-server
- user-server(gateway-client)