package test.aop;

public interface ITarget {

	String speak(Integer age);
	
}
