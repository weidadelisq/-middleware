package test.aop2;

public class UserController {
	public void login(String name){
		System.out.println("I'm "+name+" ,I'm logining");
	}
	
}
