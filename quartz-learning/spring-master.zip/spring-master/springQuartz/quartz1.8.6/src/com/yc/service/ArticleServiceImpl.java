package com.yc.service;

import org.springframework.beans.factory.annotation.Autowired;


public class ArticleServiceImpl {

	public static void copyArticle() {
		System.out.println("复制文章操作");
	}



}
