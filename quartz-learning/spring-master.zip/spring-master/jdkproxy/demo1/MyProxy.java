package com.proxy.demo1;

public interface MyProxy {

	void method1() throws InterruptedException;
	void method2() throws InterruptedException;
	void method3() throws InterruptedException;
}
