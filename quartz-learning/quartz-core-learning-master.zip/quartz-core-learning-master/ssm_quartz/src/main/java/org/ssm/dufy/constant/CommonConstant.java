package org.ssm.dufy.constant;

public class CommonConstant {

	/**
	 * 用户登录的toke
	 */
	public final static String LONGIN_TOKE = "LOGIN_TOKE"; 
}
