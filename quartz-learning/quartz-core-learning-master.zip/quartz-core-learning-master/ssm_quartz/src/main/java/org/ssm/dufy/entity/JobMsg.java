package org.ssm.dufy.entity;

public class JobMsg {
	private int id;
	private String msg;
	private String trg;
	private String mark;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getMsg() {
		return msg;
	}
	public void setMsg(String msg) {
		this.msg = msg;
	}
	public String getTrg() {
		return trg;
	}
	public void setTrg(String trg) {
		this.trg = trg;
	}
	public String getMark() {
		return mark;
	}
	public void setMark(String mark) {
		this.mark = mark;
	}
	
}
