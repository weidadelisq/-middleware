package com.googlecode.jsonrpc4j.spring.service;

public class ServiceImpl implements Service {
	
}
