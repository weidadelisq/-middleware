package com.googlecode.jsonrpc4j.spring.service;

import com.googlecode.jsonrpc4j.JsonRpcService;

@JsonRpcService("TestService")
public interface Service {
	
}
