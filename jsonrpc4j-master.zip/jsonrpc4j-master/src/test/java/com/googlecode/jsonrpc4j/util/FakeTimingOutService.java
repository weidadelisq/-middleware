package com.googlecode.jsonrpc4j.util;

public interface FakeTimingOutService {
	void doTimeout();
}
