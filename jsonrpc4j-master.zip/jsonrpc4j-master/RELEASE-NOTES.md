For a summary of releases and the changes in each release, please see:

https://github.com/briandilley/jsonrpc4j/releases